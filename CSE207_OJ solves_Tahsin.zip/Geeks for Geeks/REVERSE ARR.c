                        #include<stdio.h>


                        void linsearch();
                        void binsearch();

                        int main(){

                        int n,i,pos,key;
                        printf("choice 1.linSearch\n 2.binSearch \n ");
                        scanf("%d",&n);

                        if(n==1){
                            printf("Val: ");
                                scanf("%d",&pos);
                          linsearch(pos);
                        }

                        if(n==2){
                               printf("Val: ");
                                scanf("%d",&key);
                         binsearch(key);
                        }
                        }


                        void linsearch(int pos){
                        int i,j,x,k=0;
                        int arr[100];

                         printf("Input limit:");
                        scanf("%d",&x);
                        for (i=0;i<x;i++){
                                printf("Input vals:");
                            scanf("%d",&arr[i]);
                        }
                        for(i=0;i<x;i++){
                                if(arr[i]==pos){
                                printf("%d is ditected at position %d",pos,k+1);
                                break;
                                }
                                k++;

                        }
                        }



             void binsearch(key){
                        int i,j,x,k=0;

                        int arr[100];

                         printf("Input limit:");
                        scanf("%d",&x);
                        for (i=0;i<x;i++){
                                printf("Input vals:");
                            scanf("%d",&arr[i]);
                        }
                        int f=0,l=x,m;


                        while(f<=l){
                        m=(f+l)/2;
                        if(key==arr[m]){
                            printf("%d is ditected ",key);
                            break;
                        }
                        else if(key>arr[m]){
                            f=m+1;
                        }
                        else if(key<arr[m]){
                            l=m-1;
                        }
                        else{
                            printf("Not found");
                        }

                        }

             }
