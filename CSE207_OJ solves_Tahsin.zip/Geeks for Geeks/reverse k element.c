#include<stdio.h>

struct stack
{
    int data;
    struct stack *nxtptr;
}*front=NULL,*rear=NULL;

void Enqueue();
void display();

void dequeue();
void rev();

int main()
{
    int i,j,k,n,m,x;
printf("Limit:");
scanf("%d",&n);
printf("pos:");
scanf("%d",&m);

for(i=0;i<n;i++){
scanf("%d",&x);
Enqueue(x);
}

rev();
//display();

}

int size(){
struct stack *tp=front;
int c=0;
while(rear!=NULL){
    c++;
    tp=tp->nxtptr;
}
return c;
}



void rev(){
struct stack *tmp,*tmp2,*tmp3;

if(size()==0 || size<0 ){
    return;
}

else{
  while(front!=NULL){
  tmp=front->data;
  dequeue();
  return tmp->data;
 // tmp=front;
  }

  }



}







//Exercise 1:Create Queue (Enqueue)

void Enqueue(int data)
{
    struct stack *newNode;
    newNode=(struct stack*)malloc(sizeof(struct stack));
    newNode->data=data;
    newNode->nxtptr=NULL;
    if(front==NULL)
    {
        front=rear=newNode;
    }
    else
    {
        rear->nxtptr=newNode;
        rear=newNode;
    }
}

void display()
{
    int i;
    struct stack*tmp;
    if(front==NULL||rear==NULL)
    {
        printf("No data entered.\n");
    }
    else
    {
        tmp=front;
        while(tmp!=NULL)
        {
            printf("%d\n",tmp->data);
            tmp=tmp->nxtptr;
        }
    }
}



 //ex-2 Delete node from Queue (Dequeue)

void dequeue()
{
    if(front==NULL)
    {
        printf("No data entered.\n");
    }
    else
    {
        struct stack *tmp;
        tmp=front;
        front=front->nxtptr;
        return (tmp->data);
        free(tmp);

    }
}




/*
//Exercise 4:CopyQueue

int copyQueue()
{
        struct stack *tmp;
        if(front==NULL)
    {
        printf("No data entered.\n");
    }
    else
    {
        for(int i=front;i<=rear;i++)
        {
        tmp=front;
        front=front->nxtptr;
        printf("%d\n",tmp->data);
        free(tmp);

        }

    }
}




 //Exercise 6:Delete all Negative Integer


void findNegative()
{
    struct stack *tmp=NULL;
    tmp=front;
    while(tmp!=NULL)
    {
        if(tmp->data<0)
        {
            dequeue(tmp->data);
        }
        else
        {
            printf("%d ",tmp->data);
        }
         tmp=tmp->nxtptr;
    }
}
*/
