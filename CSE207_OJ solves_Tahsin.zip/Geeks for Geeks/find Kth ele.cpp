        #include<stdio.h>
        #include <stdlib.h>


        struct node{
            int data;
            struct node *next;
        }*head;

        void CreateNodeLists(int n);
        void DisplayLists();
        void revDisplayLists();
         void div(int pos);

        int main(){
            int n,pos;
            printf("NUMBS OF node: ");
        scanf("%d",&n);
        CreateNodeLists(n);
         printf("\n Data entered in the list :");
        DisplayLists();

        //revDisplayLists();
        printf("give me pos:");
          scanf("%d",&pos);
          div( pos);
        DisplayLists();
        //return 0;
        }


        void CreateNodeLists(int n){
        struct node *fnnode,*tmp;
        int num,i;
        head=(struct node*)malloc(sizeof(struct node));//7 no line
        printf("input data for node1: ");
        scanf("%d",&num);
        head -> data=num;
        head -> next=NULL;
        tmp=head;//both r pointers, head r address

        for(i=2;i<=n;i++){
        printf("input data for node%d: ",i);
        fnnode=(struct node*)malloc(sizeof(struct node));//4 no line r struct tai kaj korbe
        if(fnnode==NULL){
            printf("not allocated :Null");
        }
        else{

        scanf("%d",&num);
        fnnode -> data=num;
        fnnode -> next=NULL;

        tmp->next=fnnode;//tmp r next means head er next(fnnode r address)
        tmp=fnnode;
        }

        }}

        void DisplayLists(){
        struct node *tmp;
        if(head == NULL){
            printf("empty");
        }
        else{
            tmp=head;
            while(tmp!=NULL){
                    printf("%d\t",tmp ->data);//tmp r dada print
              tmp=tmp->next;
            }
        }
        }







/*
      void div(struct  node *head,int pos){
    struct node *pre=NULL,*curr=head,*nxt;
       int c=0,i=0;

    while (curr!=0 && c<pos){
    nxt=curr->next;
    curr->next=pre;

    pre=curr;
    curr=nxt;
    c++;
    }
if(nxt!=NULL){
    head->next= div(nxt,pos);
    return pre;
}
      }

*/
        void revDisplayLists(){
        struct node *prev=NULL,*post=NULL;

        prev=head;
        post=head->next;
        head=head->next;
        prev->next=NULL;
        while(head!=NULL){

        head=head->next;
        post->next=prev;
        prev=post;
        post=head;
        }
    head=prev;

        }



