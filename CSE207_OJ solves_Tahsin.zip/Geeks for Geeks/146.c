//last node To First node
#include<stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *next;
}*head;

void CreateNodeLists(int n);
void DisplayLists();
void revDisplayLists();
void lastToFirst();
int main(){
    int n;
    printf("NUMBS OF node: ");
scanf("%d",&n);
CreateNodeLists(n);
 printf("\n Data entered in the list :");
DisplayLists();


//revDisplayLists();
printf("\n last to first node:");

lastToFirst();
DisplayLists();
return 0;
}

void CreateNodeLists(int n){

struct node *fnnode,*tmp;
int num,i;

head=(struct node*)malloc(sizeof(struct node));//7 no line


printf("input data for node1: ");
scanf("%d",&num);

head -> data=num;
head -> next=NULL;
tmp=head;//both r pointers, head r address


for(i=2;i<=n;i++){
printf("input data for node%d: ",i);
fnnode=(struct node*)malloc(sizeof(struct node));//4 no line r struct tai kaj korbe
if(fnnode==NULL){
    printf("not allocated :Null");
}
else{

scanf("%d",&num);
fnnode -> data=num;
fnnode -> next=NULL;

tmp->next=fnnode;//tmp r next means head er next(fnnode r address)
tmp=fnnode;
}

}}

void DisplayLists(){
struct node *tmp;
if(head == NULL){
    printf("empty");
}
else{
    tmp=head;
    while(tmp!=NULL){
            printf("%d\t",tmp ->data);//tmp r dada print
      tmp=tmp->next;
    }
}
}

void lastToFirst(){
struct node *temp1,*temp2,*temp3;

temp1=head;
temp2=head;

while(1){
    if(temp2->next==NULL)
{
    break;
}
else{
    temp3=temp2;
}
temp2=temp2->next;
}

temp2->next=head;
temp3->next=NULL;
head=temp2;
}




/*void lastToFirst(){
struct node *tmp2=NULL,*tmp;
tmp=head;
while(tmp!=NULL){
   tmp2=tmp->next;
   while(tmp2->next==NULL){
    tmp2->next=head;
    head=tmp2;
    tmp->next=NULL;
   }
   tmp2=tmp2->next;
}
}*/












void revDisplayLists(){
struct node *pre=NULL,*post=NULL;

pre=head;
post=head->next;
head=head->next;
pre->next=NULL;

while(head!=NULL){
        head=head->next;
        post->next=pre;
   pre=post;
   post=head;
}
head=pre;
return head;
}



