#include<stdio.h>
int main() {
    printf("97 e a\n");
    printf("98 e b\n");
    printf("99 e c\n");
    printf("100 e d\n");
    printf("101 e e\n");
    printf("102 e f\n");
    printf("103 e g\n");
    printf("104 e h\n");
    printf("105 e i\n");
    printf("106 e j\n");
    printf("107 e k\n");
    printf("108 e l\n");
    printf("109 e m\n");
    printf("110 e n\n");
    printf("111 e o\n");
    printf("112 e p\n");
    printf("113 e q\n");
    printf("114 e r\n");
    printf("115 e s\n");
    printf("116 e t\n");
    printf("117 e u\n");
    printf("118 e v\n");
    printf("119 e w\n");
    printf("120 e x\n");
    printf("121 e y\n");
    printf("122 e z\n");
    return 0;
}
