#include <stdio.h>
int main()
{
    double M, P;
    scanf("%lf %lf", &M, &P);
    printf("%.2lf\n", M/P);
    return 0;
}
