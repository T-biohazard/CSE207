#include<stdio.h>
int main()
{
printf("<AMO FAZER EXERCICIO NO URI>\n");

printf("<    AMO FAZER EXERCICIO NO URI>\n");

printf("<AMO FAZER EXERCICIO >\n");

printf("<AMO FAZER EXERCICIO NO URI>\n");

printf("<AMO FAZER EXERCICIO NO URI    >\n");

printf("<AMO FAZER EXERCICIO NO URI>\n");

printf("<          AMO FAZER EXERCICIO >\n");

printf("<AMO FAZER EXERCICIO           >\n");
return 0;
}
