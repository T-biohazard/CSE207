#include<stdio.h>
int main()
{
printf("234.345000 - 45.698000\n");
printf("234 - 46\n");
printf("234.3 - 45.7\n");
printf("234.34 - 45.70\n");
printf("234.345 - 45.698\n");
printf("2.343450e+02 - 4.569800e+01\n");
printf("2.343450E+02 - 4.569800E+01\n");
printf("234.345 - 45.698\n");
printf("234.345 - 45.698\n");
return 0;
}
