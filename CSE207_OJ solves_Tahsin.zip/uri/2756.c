#include<stdio.h>
int main()
{
	printf("       A\n");
	printf("      B B\n");
	printf("     C   C\n");
	printf("    D     D\n");
	printf("   E       E\n");
	printf("    D     D\n");
	printf("     C   C\n");
	printf("      B B\n");
	printf("       A\n");
	return 0;
}
