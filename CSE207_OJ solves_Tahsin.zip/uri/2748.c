#include<stdio.h>
int main()
{
printf("---------------------------------------\n");
printf("|        Roberto                      |\n");
printf("|                                     |\n");
printf("|        5786                         |\n");
printf("|                                     |\n");
printf("|        UNIFEI                       |\n");
printf("---------------------------------------\n");
return 0;
}
