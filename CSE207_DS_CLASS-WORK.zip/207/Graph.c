
// to represent a graph adj matrix and adj list

//a[i],a[j]=1 thn they are adj

//O(n^2)
