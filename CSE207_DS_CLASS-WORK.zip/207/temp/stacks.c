#include<stdio.h>
struct stack{
int data;
struct stack *next;

} *top=NULL;

void push(int element);
void pop();
void display();
void exit();



int main(){


}

void push(int element){

struct stack *newNode;
newNode= malloc(sizeof(newNode));

if(newNode==NULL){
    printf("stack overflow");
    exit();
}
else{
    newNode->data=element;
    newNode->next=NULL;

    newNode->next=top;
    top=newNode;
}
}

void pop(){
struct stack *temp;
int k;
temp=top;
k=temp->data;
top=top->next;
free(temp);
}


void display(){
struct stack *tmp;
tmp=top;
printf("\nThe elements are:\n");
while (tmp){ //temp!=0
    printf("here we got: \n%d\n",tmp->data);
    tmp=tmp->next;
}
}
