#include<stdio.h>
#define Size 100
struct stack
{
    int data;
    struct stack *nxtptr;
}*front,*rear;


void Enqueue(int data);
void dequeue();
void display();


int main()
{
    front=NULL;
    rear=NULL;
        int ch,data;



}





void Enqueue(int data)
{
    struct stack *newNode;
    newNode=(struct stack*)malloc(sizeof(struct stack));
    newNode->data=data;
    newNode->nxtptr=NULL;
    if(front==NULL&& rear==NULL)
    {
        front=rear=newNode;
    }
    else
    {
        rear->nxtptr=newNode;
        rear=newNode;
    }
}

void display()
{
    int i;
    struct stack*tmp;
    if(front==NULL||rear==NULL)
    {
        printf("No data entered.\n");
    }
    else
    {
        tmp=front;
        while(tmp!=NULL)
        {
            printf("%d\n",tmp->data);
            tmp=tmp->nxtptr;
        }
    }
}

void dequeue()
{
    if(front==NULL)
    {
        printf("No data entered.\n");
    }
    else
    {
        struct stack *tmp;
        tmp=front;
        front=front->nxtptr;
        return (tmp->data);
        free(tmp);
    }
}


