#include <stdio.h>
    #include <stdlib.h>

    struct dnode
    {
        int data;
        struct dnode *next;

    }*head;

    int main()
    {
        int n;

        printf("Input the number of nodes 1 : ");
        scanf("%d", &n);
        createNodeList(n);

        copylist();
          displayList();
        return 0;
    }

    void createNodeList(int n)
    {
        struct dnode *fnNode, *tmp;
        int num, i;
        head = (struct dnode *)malloc(sizeof(struct dnode));

        if(head == NULL)
        {
            printf(" Memory can not be allocated.");
        }
        else
        {


            printf(" Input data for node 1 : ");
            scanf("%d", &num);
            head->data = num;
            head->next = NULL; // links the address field to NULL
            tmp = head;

            for(i=2; i<=n; i++)
            {
                fnNode = (struct dnode *)malloc(sizeof(struct dnode));
                if(fnNode == NULL)
                {
                    printf(" Memory can not be allocated.");
                    break;
                }
                else
                {
                    printf(" Input data for node %d : ", i);
                    scanf(" %d", &num);

                    fnNode->data = num;
                    fnNode->next = NULL;

                    tmp->next = fnNode;
                    tmp = fnNode;
                }
            }
        }
    }




   void copylist()
    {

     struct dnode *newNode,*tmp;
        if(head==NULL){
                return 0;
        }
        else{
            tmp=head;
            newNode = (struct dnode*)malloc(sizeof(struct dnode));

         while(tmp->next!=NULL){
            newNode=tmp;

         }
         //printf("Copy Data : %d",newnode->data);
            //newnode= head->next;
        }
        head=head->next;
        newNode->next=tmp->next;
        tmp=tmp->next;
        }
/*{
     if (head == NULL) {
        printf("NO data found in the list.");
    }
    else {
        struct Node* newNode,*tmp;
        newNode= (struct Node*)malloc(sizeof(struct Node));
        tmp=head;
        while(tmp->nextptr!=NULL)
        {
        newNode->data = tmp->data;
        newNode->nextptr=tmp->nextptr;
        tmp=tmp->nextptr;

        }

*/

    void displayList()
    {
        struct dnode *tmp;
        if(head == NULL)
        {
            printf("List is empty.");
        }
        else
        {
            tmp = head;
            while(tmp != NULL)
            {
                printf(" Data = %d\n", tmp->data);
                tmp = tmp->next;
            }
        }
    }
