#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *left;
    struct Node *right;
};
void inorderTraversal(struct Node* root)
{
    if(root==NULL)
        return;
    inorderTraversal(root->left);
    printf("%d ",root->data);
    inorderTraversal(root->right);
}
void preorderTraversal(struct Node* root)
{
    if(root==NULL)
        return;
    printf("%d ",root->data);
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}
void postorderTraversal(struct Node* root)
{
    if(root==NULL)
        return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    printf("%d ",root->data);
}
struct Node *CreatNode()
{
    int x;
    struct Node *newNode=malloc(sizeof(struct Node));
    printf("Enter a data: ");
    scanf("%d",&x);
    newNode->data=x;
    newNode->left=NULL;
    newNode->right=NULL;
    return newNode;
}
struct Node *insertLeft(struct Node *root)
{
    root->left=CreatNode();
    return root->left;
};

struct Node *insertRight(struct Node *root)
{
    root->right=CreatNode();
    return root->right;
};

int main()
{
    struct Node *root;
    root= CreatNode();
    insertLeft(root);
    insertRight(root);

    insertLeft(root->left);
    insertRight(root->left);
    insertLeft(root->left->right);

    printf("In order Traversal: \n");
    inorderTraversal(root);
    printf("\nPre order Traversal: \n");
    preorderTraversal(root);
    printf("\nPost order Traversal: \n");
    postorderTraversal(root);
}
