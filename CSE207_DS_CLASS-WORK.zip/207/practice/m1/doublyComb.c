#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node*PreNode;
    struct Node*NxtNode;
}*b,*h,*z;
void CreateDobListb(int n);
void DisplaydDobListb();
int main()
{
    int n;
    printf("Enter the size of 1st linked list: ");
    scanf("%d",&n);
    CreateDobListb(n);
    printf("\n\nThe data entered in the 1st list is: \n");
    DisplaydDobListb();
    printf("\nEnter the size of 2nd linked list: ");
    scanf("%d",&n);
    CreateDobListh(n);
    printf("\n\nThe data entered in the 2nd list is: \n");
    DisplaydDobListh();
    printf("\nCombine above lists: \n");
    FUN1();
    printf("\n\nAfter combine them we get: \n");
    DisplaydDobListz();
}
void CreateDobListb(n)
{
    struct Node*NewNode,*tmp;
    int data,i;
    b=(struct Node*)malloc(sizeof(struct Node));
    if(b==NULL)
    {
        printf("Memory can not be allocated.");
    }
    else
    {
        printf("Enter the data for node 1: ");
        scanf("%d",&data);
        b->data=data;
        b->PreNode=NULL;
        b->NxtNode=NULL;
        tmp=b;
        for(i=2;i<=n;i++)
        {
        NewNode=(struct Node*)malloc(sizeof(struct Node));
        if(NewNode==NULL)
        {
            printf("Memory can not be allocated.");
        }
        else
        {
            printf("Enter the data for node %d: ",i);
            scanf("%d",&data);
            NewNode->data=data;
            tmp->NxtNode=NewNode;
            NewNode->PreNode=tmp;
            NewNode->NxtNode=NULL;
            tmp=NewNode;

        }
        }
    }
}
void DisplaydDobListb()
{
    struct Node*tmp;
    if(b==NULL)
    {
        printf("No data found in the list.");
    }
    else
    {
        tmp=b;
        while(tmp!=NULL)
        {
            printf("Data: %d\n",tmp->data);
            tmp=tmp->NxtNode;
        }
    }
}

void CreateDobListh(n)
{
    struct Node*NewNode,*tmp;
    int data,i;
    h=(struct Node*)malloc(sizeof(struct Node));
    if(h==NULL)
    {
        printf("Memory can not be allocated.");
    }
    else
    {
        printf("Enter the data for node 1: ");
        scanf("%d",&data);
        h->data=data;
        h->PreNode=NULL;
        h->NxtNode=NULL;
        tmp=h;
        for(i=2;i<=n;i++)
        {
        NewNode=(struct Node*)malloc(sizeof(struct Node));
        if(NewNode==NULL)
        {
            printf("Memory can not be allocated.");
        }
        else
        {
            printf("Enter the data for node %d: ",i);
            scanf("%d",&data);
            NewNode->data=data;
            tmp->NxtNode=NewNode;
            NewNode->PreNode=tmp;
            NewNode->NxtNode=NULL;
            tmp=NewNode;

        }
        }
    }
}
void DisplaydDobListh()
{
    struct Node*tmp;
    if(h==NULL)
    {
        printf("No data found in the list.");
    }
    else
    {
        tmp=h;
        while(tmp!=NULL)
        {
            printf("Data: %d\n",tmp->data);
            tmp=tmp->NxtNode;
        }
    }
}
void FUN1()
{
    struct Node *link;
    z=(struct Node*)malloc(sizeof(struct Node));
    z=b;
    link=z;
    while(link->NxtNode!=NULL)
    {
        link=link->NxtNode;
    }
    link->NxtNode=h;
    h->PreNode=link;
    while(link->NxtNode!=NULL)
    {
        link=link->NxtNode;
    }
}
void DisplaydDobListz()
{
    struct Node*tmp;
    if(z==NULL)
    {
        printf("No data found in the list.");
    }
    else
    {
        tmp=z;
        while(tmp!=NULL)
        {
            printf("Data: %d\n",tmp->data);
            tmp=tmp->NxtNode;
        }
    }
}
