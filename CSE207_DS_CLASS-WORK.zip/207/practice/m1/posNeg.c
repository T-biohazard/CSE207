#include<stdio.h>
#include <stdlib.h>


struct node{
    int data;
    struct node *next;
}*head;

void CreateNodeLists(int n);
void DisplayLists();

void posNeg();
void prime();

int main(){
    int n,g;
    printf("NUMBS OF node: ");
scanf("%d",&n);
CreateNodeLists(n);
printf("\n Data entered in the list :");
DisplayLists();

posNeg();

return 0;
}

void CreateNodeLists(int n){

struct node *fnnode,*tmp;
int num,i;

head=(struct node*)malloc(sizeof(struct node));//7 no line


printf("input data for node1: ");
scanf("%d",&num);

head -> data=num;
head -> next=NULL;
tmp=head;//both r pointers, head r address


for(i=2;i<=n;i++){
printf("input data for node%d: ",i);
fnnode=(struct node*)malloc(sizeof(struct node));//4 no line r struct tai kaj korbe
if(fnnode==NULL){
    printf("not allocated :Null");
}
else{

scanf("%d",&num);
fnnode -> data=num;
fnnode -> next=NULL;

tmp->next=fnnode;//tmp r next means head er next(fnnode r address)
tmp=fnnode;
}

}}

void posNeg(){

struct node *gg=head;
int m;
m=head->data;
if(head->data==NULL){
    printf("empty");
}
else{

while(m!=NULL){
gg->data=m;
if(gg>=0){
    printf("\n%d is positive",m);
    prime();//**prime
}
else{
    printf("\n%d is negative",m);
}
gg=gg->next;
}
}}

void prime(){
struct node *gg=head;
int p;

p=head->data;
if(head->data==NULL){
   printf("empty head");
}
else{
    p=gg->data;
if(p==1){
    printf(" ");
}
else{
        for(int i=2;i<=p/2;i++){
            if(p%i==NULL){
               printf(" ");
            }
            else{
              printf("%d is not a prime number",p);
            }
        }
}
}
gg->data=gg->next;
}


void DisplayLists(){
struct node *tmp;
if(head == NULL){
    printf("empty");
}
else{
    tmp=head;
    while(tmp!=NULL){
            printf("%d\t",tmp ->data);//tmp r dada print
      tmp=tmp->next;
    }
}
}



