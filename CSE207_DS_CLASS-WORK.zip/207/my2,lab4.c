
#include <stdio.h>

struct node{
int data;
struct node *left,*right;
};

struct node* Findlarge(struct node *root,int k)
{
    int i=0;
    if (root ==NULL) {
        return;
    }
    struct node* left = Findlarge(root->right, k);
    if (left) {
        return left;
    }
    ++i;
    if (i == k) {
        return root;
    }
    return Findlarge(root->left, k);
};

 int findKthLargest(struct node* root, int k)
{
    struct node *tmp;
    tmp=root;

    return Findlarge(tmp,k);
}


int main(){
struct node *root,*p,*m,*q;
int i,j,n,item;

printf("Enter the node limits:");
scanf("%d",&n);
printf("Enter data:");
for(i=0;i<n;i++){

p=(struct node*)malloc(sizeof(struct node));
scanf("%d",&item);
p->data=item;
p->left=NULL;
p->right=NULL;


if(i==0){
    root=p;
}
else{
q=root;
while(1){
if(p->data>q->data){
if(q->right==NULL){
    q->right=p;
    break;
}
else{
    q=q->right;
}
}
else{
if(q->left==NULL){
 q->left=p;
  break;
}
else{
    q=q->left;
}
}
}
}
}

printf("\n  ");
 int a;
    printf("\n position K'th: ");
    scanf("%d",&a);
    m=findKthLargest(root,a);
    printf("\n%d",m->data);
}
