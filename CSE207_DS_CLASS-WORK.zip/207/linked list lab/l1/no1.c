#include<stdio.h>
#include <stdlib.h>


struct node{
    int data;
    struct node *next;
}*head;

void CreateNodeLists(int n);
void DisplayLists();


int main(){
    int n,g;
    printf("NUMBS OF node: ");
scanf("%d",&n);
CreateNodeLists(n);
 printf("\n Data entered in the list :");
DisplayLists();



return 0;
}

void CreateNodeLists(int n){

struct node *fnnode,*tmp;
int num,i;

head=(struct node*)malloc(sizeof(struct node));//7 no line


printf("input data for node1: ");
scanf("%d",&num);

head -> data=num;
head -> next=NULL;
tmp=head;//both r pointers, head r address


for(i=2;i<=n;i++){
printf("input data for node%d: ",i);
fnnode=(struct node*)malloc(sizeof(struct node));//4 no line r struct tai kaj korbe
if(fnnode==NULL){
    printf("not allocated :Null");
}
else{

scanf("%d",&num);
fnnode -> data=num;
fnnode -> next=NULL;

tmp->next=fnnode;//tmp r next means head er next(fnnode r address)
tmp=fnnode;
}

}}
Node* newNode(int data)
{
    Node* new_node = new Node;
    new_node->data = data;
    new_node->next = NULL;
    return new_node;
}

Node* fractionalNodes(Node* head, int k)
{
    if (k <= 0 || head == NULL)
        return NULL;

    Node* fractionalNode = NULL;

    int i = 0;
    for (Node* temp = head; temp != NULL; temp = temp->next) {

        if (i % k == 0) {


            if (fractionalNode == NULL)
                fractionalNode = head;

            else
                fractionalNode = fractionalNode->next;
        }
        i++;
    }
    return fractionalNode;
}

void printList(Node* node)
{
    while (node != NULL) {
        printf("%d ", node->data);
        node = node->next;
    }
    printf("\n");
}


