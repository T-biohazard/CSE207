#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node* left;
    struct Node* right;
};
struct Node *root;
void inorderTraversal(struct Node* root)
{
    if(root==NULL)
        return;
    inorderTraversal(root->left);
    printf("%d ",root->data);
    inorderTraversal(root->right);
}
unsigned int getLeafCount(struct Node* root)
{
  if(root == NULL)
    return 0;
  if(root->left == NULL && root->right==NULL)
    return 1;
  else
    return getLeafCount(root->left)+getLeafCount(root->right);
}

void insert(int data)
{
   struct Node *tempNode = (struct Node*) malloc(sizeof(struct Node));
   struct Node *current;
   struct Node *parent;

   tempNode->data = data;
   tempNode->left = NULL;
   tempNode->right = NULL;

   if(root == NULL) {
      root = tempNode;
   }
   else {
      current = root;
      parent = NULL;

      while(1) {
         parent = current;

         if(data < parent->data) {
            current = current->left;

            if(current == NULL) {
               parent->left = tempNode;
               return;
            }
         }
         else {
            current = current->right;

            if(current == NULL) {
               parent->right = tempNode;
               return;
            }
         }
      }
   }
}

int main()
{
  int num;
    int n;
    printf("How many node you want: ");
    scanf("%d",&n);

    printf("Enter data: ");
    for(int i=0;i<n;i++)
    {
    scanf("%d",&num);
    insert(num);
    }
inorderTraversal(root);
  printf("Leaf count of the tree is %d", getLeafCount(root));

  getchar();
  return 0;
}
