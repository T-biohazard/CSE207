#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node *root;
void inOrder(struct Node* root)
{
    if(root==NULL)
        return;
    inOrder(root->left);
    printf("%d ",root->data);
    inOrder(root->right);
}
unsigned int LeafNodes(struct Node* root)
{
  if(root == NULL)
    return 0;
  if(root->left == NULL && root->right==NULL)
    return 1;
  else
    return LeafNodes(root->left)+LeafNodes(root->right);
}

int main()
{
  int x;
    int n;
    printf("number of nodes: ");
    scanf("%d",&n);
printf("Enter data: ");
    for(int i=0;i<n;i++)
    {
    scanf("%d",&x);
    insert(x);
    }
  inOrder(root);
  printf("Numbs of Leaf Nodes %d", LeafNodes(root));

  getchar();
  return 0;
}

void insert(int data)
{
   struct Node *tmp = (struct Node*) malloc(sizeof(struct Node));
   struct Node *p;
   struct Node *q;

   tmp->data = data;
   tmp->left = NULL;
   tmp->right = NULL;

   if(root == NULL) {
      root = tmp;
   }
   else {
      p = root;
      q = NULL;

      while(1) {
         q = p;

         if(data < q->data) {
            p = p->left;

            if(p == NULL) {
               q->left = tmp;
               return;
            }
         }
         else {
            p = p->right;

            if(p == NULL) {
               q->right = tmp;
               return;
            }
         }
      }
   }
}


