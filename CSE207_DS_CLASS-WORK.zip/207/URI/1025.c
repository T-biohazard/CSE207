
#include<stdio.h>

void bubbleSort();
void binsearch();

main(){
int n,m,x,i,j;
int arr[100];
arr1[100];

scanf("%d %d",&n,&x);

 for(i=0;i<n;i++)
    scanf("%d",&arr[n]);

 for(j=0;j<x;j++)
    scanf("%d",&arr1[x]);


    //sort

 int t,s;
    for(t=0;t<n-1;t++){
        for(s=0;s<n-1-t;s++){ //compare
            if(arr[s]>arr[s+1]){
                int temp = arr[s];
                arr[s]=arr[s+1];
                arr[s+1]=temp;
            }
        }
    }

    //search
     int f=0,l=x,m,c=0;

    while(f<=l){
    m=(f+l)/2;
    if(key==arr[m]){
            c++;
        printf("%d is found at %d",key,c);
        break;
    }
    else if(key>arr[m]){
        f=m+1;
    c++;
    }
    else if(key<arr[m]){
        l=m-1;
        c++;
    }
    else{
        printf("%d Not found",key);
    }
    }
    }






/*
 void bubbleSort(){
    int i,j,x;
    int arr[100];

     printf("Input limit:");
    scanf("%d",&x);
    for (i=0;i<x;i++){
            printf("Input vals:");
        scanf("%d",&arr[i]);
    }
    for(i=0;i<x-1;i++){
        for(j=0;j<x-1-i;j++){ //compare
            if(arr[j]>arr[j+1]){
                int temp = arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
     printf("sorted form: ");
    for(i=0;i<x;i++)
    printf("\t%d",arr[i]);
    }

*/

/*
    void binsearch(key){
    int i,j,x,k=0;
    int arr[100];

     printf("Input limit:");
    scanf("%d",&x);
    for (i=0;i<x;i++){
            printf("Input vals:");
        scanf("%d",&arr[i]);
    }
    int f=0,l=x,m,c=0;

    while(f<=l){
    m=(f+l)/2;
    if(key==arr[m]){
            c++;
        printf("%d is found at %d",key,c);
        break;
    }
    else if(key>arr[m]){
        f=m+1;
    c++;
    }
    else if(key<arr[m]){
        l=m-1;
        c++;
    }
    else{
        printf("%d Not found",key);
    }
    }
    }
*/
