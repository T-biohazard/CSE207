#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node* left;
    struct node* right;
};
struct node *root = NULL;
int array[1000];
x=0;
void Path(struct node* node)
{
    path(node, array, x);
}
void path(struct node* node, int array[], int x)
{
    if (node==NULL)
        return;

    array[x] = node->data;
    x++;

    if (node->left==NULL && node->right==NULL)
    {
        printVal(array, x);
    }
    else
    {
        path(node->left, array, x);
        path(node->right, array, x);
    }
}
void insert(int data)
{
    struct node *tempNode = (struct node*) malloc(sizeof(struct node));
    struct node *current;
    struct node *parent;

    tempNode->data = data;
    tempNode->left = NULL;
    tempNode->right = NULL;

    if(root == NULL)
    {
        root = tempNode;
    }
    else
    {
        current = root;
        parent = NULL;

        while(1)
        {
            parent = current;

            if(data < parent->data)
            {
                current = current->left;

                if(current == NULL)
                {
                    parent->left = tempNode;
                    return;
                }
            }
            else
            {
                current = current->right;

                if(current == NULL)
                {
                    parent->right = tempNode;
                    return;
                }
            }
        }
    }
}

void inorder(struct node* root)
{
    if(root != NULL)
    {
        inorder(root->left);
        printf("%d ",root->data);
        inorder(root->right);
    }
}

void printVal(int printPath[], int y)
{
    int i;
    for (i=0; i<y; i++)
    {
        printf("%d ", printPath[i]);
    }
    printf(" \n");
}

int main()
{
    int i,num;
    printf("How much data you enter:");
    scanf("%d",&num);
    for(i = 0; i < num; i++)
    {
        printf("Enter node for %d-> ",i+1);
        scanf("%d",&array[i]);
        insert(array[i]);
    }
    printf("\n\t\tLongest  paths: \n");
    Path(root);
    printf("\n\t\tInorder traversal:\n");
    inorder(root);

}
