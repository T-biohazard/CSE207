
//5.3 jnnys-5.6

#include<stdio.h>

struct node{
int data;
struct node *left,*right;

};


struct node *create(){
    int x;
struct node *newNode=malloc(sizeof(struct node));

printf("Input data(nb: input -1 to stop):");
scanf("%d",&x);
if(x==-1){
    return 0;
}
newNode->data=x;

printf("Enter left data of %d \n",x);
newNode->left=create();


printf("Enter right data of %d \n",x);
newNode->right=create();

return newNode;
};

void main(){
struct main *root=NULL;
root=create();

printf("\n in-order:");
inOrder(root);

printf("\n Pre-order:");
PreOrder(root);

printf("\n leaves:");

//count_leaves(root);

printf("\n max height: %d",maxDepth(root));
printf("\n min height: %d",minDepth(root));

}




int maxDepth(struct node* root)
{
    if (root == NULL)
        return -1;
    else {
        /* compute the depth of each subtree */
        int lDepth = maxDepth(root->left);
        int rDepth = maxDepth(root->right);

        /* use the larger one */
        if (lDepth > rDepth)
            return (lDepth + 1);
        else
            return (rDepth + 1);
    }
}


int minDepth(struct node* root)
{
    if (root == NULL)
    {
        return 0;
    }
    return minDepth(root->left)+ minDepth(root->right);
}


/*
int count_leaves(struct node *root){
int c=0;
if(root){
    if(root->left==NULL && root->right==NULL){
        c++;
    }
else{

    if(root->left)
       count_leaves(root->left);
    if(root->right)
       count_leaves(root->right);

}
}
printf("%d",c);
}
*/


void inOrder(struct node *root){
if(root==NULL)
    return;

inOrder(root->left);
printf("%d",root->data);
inOrder(root->right);
}

void PreOrder(struct node *root){
if(root==NULL)
    return;

printf("%d",root->data);
PreOrder(root->left);
PreOrder(root->right);
}
