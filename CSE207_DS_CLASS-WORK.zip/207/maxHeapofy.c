#include <stdio.h>
#include <stdlib.h>


void maXheapify(int arr[],int n,int i){
int largest=i;
int l=2*i;
int r=(2*i)+1;

while(l<=n  &&  arr[l]>arr[largest]){
    largest=l;
}

while(r<=n  &&  arr[r]>arr[largest]){
    largest=r;
}

if(largest != i){
    swap(arr[largest],arr[i]);
    maXheapify( arr, n, largest);
}
}

void swap(int x,int y){
int temp=x;
x=y;
y=temp;
}

void buildheapify(int arr[],int n){
for(int i=n/2;i>0;i--){
maXheapify(arr, n,i);
}
}

void heapSort(int arr[],int n){// 2 steps build and delete

buildheapify(arr,n);

for(int i=n;i>0;i--){
    int temp=arr[i];
    arr[i]=arr[1];
    arr[1]=temp;
    maXheapify(arr,n,1);
}
}




void printArr(int arr[],int n){
for(int i=0;i<=n;i++){     //i<n to avoid 0****
    printf("%d ",arr[i]);
}
}

int main(){

int i,n,arr[1000];
 printf("Enter the size of the array: ");
scanf("%d",&n);
   printf("Enter the elements: ");
for(i=0;i<n;i++){
    scanf("%d",&arr[i]);
}


buildheapify(arr, n);
printf("heap sort: ");
heapSort(arr,n);
printArr( arr, n);
}
