void parenthesis(char *str){

  int i,check;
  void exit();

   for(i=0; i<strlen(str); i++){
    if(str[i] == ')'){
    check = Push;
}
  else if(str[i] == '('){
  check =  Pop;
   if(check == -1){
   printf("Opening parentheses not end\n");
   return 0;
}
}
}
   check = Pop;
  if(check != -1){
  printf("Closing parentheses not matched\n");
  return 0;
}
  else{
printf("Parentheses matched\n");

}
