#include<stdio.h>
struct stack{
int data;
struct stack *next;

} *top=NULL;

void push(int element);
void pop();
void display();
void exit();

int main()
{
    char *exp;
    int t;
    scanf("%d",&t);
    while(t--)
    {
        exp = (char*)malloc(10000*sizeof(char));
        scanf("%s",exp);
        if(isBalanced(exp))
            printf("YES\n");
        else
            printf("NO\n");
        free(exp);
    }
}
int isEmpty()
{
    return top?0:1;
}

char stackTop()
{
    if(!isEmpty())
        return top->data;
    return '0';
}

int isBalanced(char *exp)
{
    int i;
    for(i=0;exp[i]!='\0';i++)
    {
        if(exp[i] == '(' || exp[i] == '{' || exp[i] == '[')
            push(exp[i]);
        else if(exp[i] == ')' || exp[i] == '}' || exp[i] == ']')
        {
            if(isEmpty())
                return 0;
            if(stackTop() == '(' && exp[i] == ')')
                pop();
            else if(stackTop() == '{' && exp[i] == '}')
                pop();
            else if(stackTop() == '[' && exp[i] == ']')
                pop();
            else
                return 0;
        }
    }
        if(isEmpty())
            return 1;
        else
            return 0;
}








void push(int element){      //ex-2

struct stack *newNode;
newNode= malloc(sizeof(newNode));

if(newNode==NULL){
    printf("stack overflow");
    exit();
}
else{
    newNode->data=element;
    newNode->next=NULL;

    newNode->next=top;
    top=newNode;
}
}

void pop(){            //ex-3
struct stack *temp;
int k;
temp=top;
k=temp->data;
top=top->next;
free(temp);
}


void display(){
struct stack *tmp;
tmp=top;
printf("\nThe elements are:\n");
while (tmp){ //temp!=0
    printf("%d\t",tmp->data);
    tmp=tmp->next;
}
}
