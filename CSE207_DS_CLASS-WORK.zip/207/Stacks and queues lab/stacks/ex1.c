#include<stdio.h>

void push(int element);
void pop();
void display();
void exit();

int main(){   //top 1 2 3
int n,m;
while(1){
printf("Choose Operation\n1.push\n2.display\n3.exit\n");
scanf("%d",&n);

if(n==1){
       printf("PUSH :");
        scanf("%d",&m);
    push(m);
}

/*if(n==2){
    pop();
}*/

if(n==2){
    display();
}
if(n==3){
    exit();
}

}}

