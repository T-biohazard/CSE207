
#include<stdio.h>

struct node{
int data;
node *next;
}*front=NULL,*rear=NULL;


void Enqueue(int val){
struct node *newnode=NULL;
newnode->data=val;
newnode->next=NULL;

if(front==NULL){

    front=rear=newnode;

}
else{        //link up krbe
    rear->next=newnode;
    rear=newnode;
}
}


void Dequeue(){
struct node *tmp=NULL;
tmp=front;


if(front==NULL){
    printf("empty queue");
}
else{
    front=front->next;
    return (tmp->data);
    free(tmp);
}
}



void cpy(){
struct node *tmp=NULL;
if(front==NULL){
    printf("empty queue");
}
else{

for(int i=front;i<=rear;i++  ){
tmp=front;
front=front->next;
return tmp->data;
free(tmp);
        }
}


}
