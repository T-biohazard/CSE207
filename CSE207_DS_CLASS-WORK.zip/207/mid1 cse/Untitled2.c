    #include <stdio.h>
    #include <stdlib.h>


    struct dnode {
        int data;
        struct dnode* next;
    }*head;


    struct dnode* insert(struct dnode *h,int d){
        struct dnode *t,*ptr,*trav;
        ptr=(struct dnode*)malloc(sizeof(struct dnode));
        ptr->next=NULL;
        ptr->data=d;
        t=h;
        if(t==NULL){
            h=ptr;
        }
        else{
            trav=h;
        while(trav->next!=NULL){
            trav=trav->next;
        }
        trav->next=ptr;
        }
        return h;
    };


    void swap(struct dnode* head, int p)

    {
        struct dnode *t=head,*t1=head,*n1=NULL,*n2=NULL,*x1=NULL,*x2=NULL;
        int l=p-2,l2=p;
        while(l!=0){
            t=t->next;
            l--;
        }
        n1=t;
        x1=t->next;
        while(l2!=0){
            t1=t1->next;
            l2--;
        }
        n2=t1;
        x2=t1->next;
        printf("%d\n",x2->data);

        n1->next=x2;

        n2->next=x1;


    }
    int main()
    {
        int i;
        printf("Enter Data: ");
        for(i=0; i<6; i++){

            int numb;
            scanf("%d",&numb);
            head=insert(head,numb);
        }
        display(head);
        printf("P=");
        int p;


        scanf("%d",&p);
        int len=length(head);

        if(len<=(p+2)){
            printf("Invalid Position\n");
        }
        else{
            swap(head,p);
            display(head);
        }
        return 0;
    }

    void display(struct dnode* dnode)
    {
        while (dnode != NULL) {
            printf("%d ", dnode->data);
            dnode = dnode->next;
        }
        printf("\n");
    }
    int length(struct dnode *t){
        int l=0;
        while(t!=NULL){


            t=t->next;
            l++;
        }
        return l;
    }
