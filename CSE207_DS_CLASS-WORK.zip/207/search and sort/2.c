
#include <stdio.h>

int main(){
    int pos,i,j;

   printf("");

scanf("%d",&pos);

}
