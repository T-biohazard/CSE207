    //Linear Search
    #include <stdio.h>
    void main()
    {
      int n, i, a[100], b, c=0;

      printf("How many data do you want to input: ");
      scanf("%d", &n);

      printf("Input the data: \n");

      for(i=0; i < n; i++)
        scanf("%d", &a[i]);

      printf("Enter a number to search: ");
      scanf("%d", &b);

      for(i=0; i<n; i++)
      {
        if(a[i]==b)
        {
          printf("Your element is found in position %d.\n", i+1);
          break;

        }
        else c++;
      }
      if(c==n)
    printf("Data not found in array\n");
    }
