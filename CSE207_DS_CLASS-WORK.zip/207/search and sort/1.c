

    #include<stdio.h>
    #include <stdlib.h>


    struct node{
        int data;
        struct node *next;
    }*head;

    void CreateNodeLists(int n);
    void DisplayLists();

     void searcLin(int pos);

    int main(){
        int n,pos;
        printf("How many data do you want to input: ");
    scanf("%d",&n);
    CreateNodeLists(n);
    printf("\n Input the data: ");
    //DisplayLists();


    printf("What element do you want to search: ");
    scanf("%d",&pos);
    searcLin(pos);

    return 0;
    }



    void CreateNodeLists(int n){
    struct node *fnnode,*tmp;
    int num,i;
    head=(struct node*)malloc(sizeof(struct node));//7 no line
    printf("input data for node1: ");
    scanf("%d",&num);
    head -> data=num;
    head -> next=NULL;
    tmp=head;//both r pointers, head r address

    for(i=2;i<=n;i++){
    printf("input data for node%d: ",i);
    fnnode=(struct node*)malloc(sizeof(struct node));//4 no line r struct tai kaj korbe
    if(fnnode==NULL){
        printf("not allocated :Null");
    }
    else{
    scanf("%d",&num);
    fnnode -> data=num;
    fnnode -> next=NULL;
    tmp->next=fnnode;//tmp r next means head er next(fnnode r address)
    tmp=fnnode;
    }
    }}


    void searcLin(int val){
    struct node *tmp=head;
    int count=0,i;
    while(head!=NULL){
        if(tmp->data==val){
            count++;
            printf("Your element is found in position: %d",count+1);
            break;
        }
        else{
        tmp=tmp->next;
}    }
    }


    void DisplayLists(){
    struct node *tmp;
    if(head == NULL){
        printf("empty");
    }
    else{
        tmp=head;
        while(tmp!=NULL){
                printf("%d\n",tmp ->data);//tmp r dada print
          tmp=tmp->next;
        }
    }
    }



