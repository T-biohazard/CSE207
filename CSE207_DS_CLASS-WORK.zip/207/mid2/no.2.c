#include<stdio.h>
struct Node{
int data;
struct Node * next;
}*front=NULL,*rear=NULL;

void enqueue(int item);
void Modify();

int main()
{
printf("Q1:");
int i,arr[100],count=0;
for(i=0; i<5; i++){
int x;
scanf("%d",&x);
if(x%2!=0){
enqueue(x);
}
else{
arr[count]=x;
count++;
}
}
int j;
for(j=0; j<count; j++){
enqueue(arr[j]);
}
Modify();

}

void enqueue(int item){
struct Node *temp;
temp=front;
temp=(struct Node*)malloc(sizeof(struct Node));
temp->next=NULL;
temp->data=item;
if(front==NULL){
front=temp;
rear=temp;

}
else{
rear->next=temp;
rear=temp;
}

}

void Modify(){
struct Node *temp;
temp=front;
printf("\nQ1: ");
while(temp!=NULL){
printf("%d ",temp->data);
temp=temp->next;
}
printf("\n");
}
