
#include <bits/stdc++.h>
using namespace std;
struct node {
    int data;
    node *link;
}*front=NULL,*rear=NULL;

bool isempty();
void enque(int val);
void dequ();
void displayQueue();
int showfront();
int que_size();
void chk(){
    int cnt=0;
    while(cnt!=5){
        cnt++;
   cout<<showfront()<<" ";
   dequ();
    }

    cout<<endl;

    if(que_size()!=0){
     while(que_size()!=0){
       dequ();
   }
    }

}

int main(){


   for(int i=0;i<25;i++){
       int x;
       cin>>x;
       if(x>0){
           enque(x);
           //  cout<<que_size()<<endl;
       }
       else if(x<0){
          // cout<<que_size()<<endl;
           if(que_size()>=5){

               chk();
           }
           else if(que_size()<5)
           {
               cout<<"Error"<<endl;
               exit(0);
           }


       }
   }

}

bool isempty(){
    if(front==NULL && rear==NULL){
      return  true;
    }
    else{
         return false;
    }
}

void enque(int val){
    node *ptr=new node;
    ptr->data=val;
    ptr->link=NULL;
    if(front==NULL){
        front=ptr;
        rear=ptr;
    }
    else{
        rear->link=ptr;
       rear=ptr;
    }
}

void dequ(){
       node *tmp;
       tmp=front;
        front=front->link;
        free(tmp);
}

void displayQueue(){
 if (isempty())
  cout<<"Queue is empty"<<endl;
 else{
  node *ptr = front;
  while( ptr!=NULL){
   cout<<ptr->data<<" ";
   ptr=ptr->link;
  }
  cout<<endl;
 }
}

int showfront(){
 if(isempty())
 return 0;
 else
 return front->data;
}

int que_size(){
    int cnt=0;
  node *ptr = front;
  while( ptr!=NULL){
  cnt++;
   ptr=ptr->link;
  }
    return cnt;
}
