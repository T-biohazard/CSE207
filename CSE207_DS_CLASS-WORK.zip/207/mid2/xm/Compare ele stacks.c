
    #include<stdio.h>
    //1
    struct stack{
    int data;
    struct stack *next;

    } *top=NULL;
    void compare();
    void push(int element);
    void pop();
    void display();
    //void sizeNao();
    void exit();

    //2
    struct stack2{
    int data2;
    struct stack2 *next2;

    } *top2=NULL;

    void push2(int element2);
    void pop2();
    void display2();
    //void sizeNao();
    void exit2();

    int main(){

    int n,i,j,s,t;

    printf("limits:");
    scanf("%d",&n);

    int k=n;
    for(i=0;i<n;i++){
    printf("val for list 1: ");
    scanf("%d",&s);
    push(s);
    }

    for(j=0;j<k;j++){
    printf("val for list 2: ");
    scanf("%d",&t);
    push2(t);
    }

    compare();

    }


    void compare(){
    struct stack *tmp=top;
    struct stack2 *tmp2=top2;
    while(tmp!=NULL){
    if(tmp->data!=tmp2->data2){
    printf("\nNot identical\n");
    break;
    }
    else{
    tmp=tmp->next;
    tmp2=tmp2->next2;
    }}
    printf("\nIdentical\n");
    }



    void push(int element){      //ex-2
    struct stack *newNode;
    newNode= malloc(sizeof(newNode));
    if(newNode==NULL){
    printf("stack overflow");
    exit();
    }
    else{
    newNode->data=element;
    newNode->next=NULL;

    newNode->next=top;
    top=newNode;
    }
    }

    void pop(){            //ex-3
    struct stack *temp;
    int k;
    temp=top;
    k=temp->data;
    top=top->next;
    free(temp);
    }
    void display(){
    struct stack *tmp;
    tmp=top;
    printf("\nThe elements are:\n");
    while (tmp){ //temp!=0
    printf("here we got: \n%d\n",tmp->data);
    tmp=tmp->next;
    }
    }


    //2
    void push2(int element2){      //ex-2
    struct stack2 *newNode;
    newNode= malloc(sizeof(newNode));
    if(newNode==NULL){
    printf("stack overflow");
    exit();
    }
    else{
    newNode->data2=element2;
    newNode->next2=NULL;

    newNode->next2=top2;
    top2=newNode;
    }
    }

    void pop2(){            //ex-3
    struct stack2 *temp;
    int k;
    temp=top2;
    k=temp->data2;
    top2=top2->next2;
    free(temp);
    }
    void display2(){
    struct stack2 *tmp;
    tmp=top2;
    printf("\nThe elements are:\n");
    while (tmp){ //temp!=0
    printf("here we got: \n%d\n",tmp->data2);
    tmp=tmp->next2;
    }
    }




