
#include <bits/stdc++.h>
using namespace std;
struct node{
    int data;
    node *link;
}*top=NULL;
//operations
void push(int val);
void display();
void pop();
bool isempty();
int top_data();
int stack_size();

int main(){
  int n;
  cin>>n;
  int y;
  cin>>y;
  push(y);
  for(int i=1;i<n;i++){
      int x;
      cin>>x;
    if(top_data()==x){
        pop();
    }
    else{
     push(x);
    }

  }
  if(stack_size()==0){
      cout<<"NULL"<<endl;
  }
  else{
      display();
  }
}

int stack_size(){
    int c=0;
    node *ptr=top;
    while(ptr!=NULL){
        c++;
        ptr=ptr->link;
    }
    return c;
}
void push(int val){
    node *ptr=new node;
    ptr->data=val;
    ptr->link=top;
    top=ptr;
}
void display(){
    node *ptr=new node;
    ptr=top;
    while(ptr!=NULL){
        cout<<ptr->data<<" ";
        ptr=ptr->link;
    }
    cout<<endl;
}
void pop(){
    node *temp;
    temp=top;
    top=top->link;
    free(temp);
    temp=NULL;
}
bool isempty(){
    if(top==NULL){
        return true;
    }
    else {
        return false;
    }
}
int top_data(){
    node *pp=top;
   return pp->data;
}
