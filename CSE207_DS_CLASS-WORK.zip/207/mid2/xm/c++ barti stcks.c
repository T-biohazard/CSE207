#include <bits/stdc++.h>
using namespace std;
//stack 1 & operation
struct node{
    int data;
    node *link;
}*top=NULL;
void push(int val);
void display();
void pop();
bool isempty();
int top_data();
int stack_size();
//stack 2 & operation

struct node2{
    int data2;
    node2 *link2;
}*top2=NULL;
void push2(int val);
void display2();
void pop2();
bool isempty2();
int top2_data2();
int stack_size2();

void equal(){
  bool ans=true;
  node *t1=top;
  node2 *t2=top2;

  while(t1!=NULL){

    if(t1->data!=t2->data2){
        ans=false;
        break;
    }

      t1=t1->link;
      t2=t2->link2;
  }
  if(ans==true){
      cout<<"Identical"<<endl;
  }
  else cout<<"Unidentical"<<endl;
}

int main(){

  int n;
  cout<<"Size"<<endl;
  cin>>n;
  cout<<"stack 1"<<endl;
  for(int i=0;i<n;i++){
      int x;
      cin>>x;
      push(x);
  }
  cout<<"stack 2"<<endl;
  for(int i=0;i<n;i++){
      int x;
      cin>>x;
      push2(x);
  }

  equal();


}
int stack_size(){
    int c=0;
    node *ptr=top;
    while(ptr!=NULL){
        c++;
        ptr=ptr->link;
    }
    return c;
}
void push(int val){
    node *ptr=new node;
    ptr->data=val;
    ptr->link=top;
    top=ptr;
}
void display(){
    node *ptr=new node;
    ptr=top;
    while(ptr!=NULL){
        cout<<ptr->data<<" ";
        ptr=ptr->link;
    }
    cout<<endl;
}

void pop(){

    node *temp;
    temp=top;
    top=top->link;
    free(temp);
    temp=NULL;
}

bool isempty(){
    if(top==NULL){
        return true;
    }
    else {
        return false;
    }
}
int top_data(){
   return top->data;
}
int stack_size2(){
    int c=0;
    node2 *ptr=top2;
    while(ptr!=NULL){
        c++;
        ptr=ptr->link2;
    }
    return c;
}
void push2(int val){
    node2 *ptr=new node2;
    ptr->data2=val;
    ptr->link2=top2;
    top2=ptr;
}
void display2(){
    node2 *ptr=new node2;
    ptr=top2;
    while(ptr!=NULL){
        cout<<ptr->data2<<" ";
        ptr=ptr->link2;
    }
    cout<<endl;
}

void pop2(){

    node2 *temp;
    temp=top2;
    top2=top2->link2;
    free(temp);
    temp=NULL;
}

bool isempty2(){
    if(top2==NULL){
        return true;
    }
    else {
        return false;
    }
}
int top2_data2(){
   return top2->data2;
}
