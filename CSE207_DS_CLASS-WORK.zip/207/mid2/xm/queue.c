
    #include<stdio.h>

    struct stack
    {
    int data;
    struct stack *nxtptr;
    }*front=NULL,*rear=NULL;

    void Enqueue(int data);
    void dequeue();
    void display();
    void exit();



    int main(){
    int x;
    for(int i=0;i<25;i++){
        printf("inputs:");
        scanf("%d",&x);

        if(x>0){
            Enqueue(x);
        }

        else if(x<0){
            if(size()>=5){
            check();
            }
            else{
            printf("\nError\n");
            breal;
            display();
            }
        }
    }
    }


    void size(){
    struct stack *ptr=front;
    int count=0;
    while(ptr!=NULL){
        count++;
        ptr=ptr->nxtptr;
    }
    return count;
    }


    void check(){//deleting
        int count=0;
        while(count!=5){
            count++;

            frontVal();
            dequeue();
        }

        /*
        if(size()!=NULL){
                while((size()!=0))
            dequeue();
        }
        */
    }

   void frontVal(){
        if(front==NULL && rear==NULL){
            return 0;}
            else{
            return front->data;}
   }



    void Enqueue(int data)
    {
    struct stack *newNode;
    newNode=(struct stack*)malloc(sizeof(struct stack));
    newNode->data=data;
    newNode->nxtptr=NULL;
    if(front==NULL)
    {
    front=rear=newNode;
    }
    else
    {
    rear->nxtptr=newNode;
    rear=newNode;
    }
    }



    void display()
    {
    int i;
    struct stack*tmp;
    if(front==NULL||rear==NULL)
    {
    printf("No data entered.\n");
    }
    else
    {
    tmp=front;
    while(tmp!=NULL)
    {
    printf("%d\n",tmp->data);
    tmp=tmp->nxtptr;
    }
    }
    }



    void dequeue()
    {
    if(front==NULL)
    {
    printf("No data entered.\n");
    }
    else
    {
    struct stack *tmp;
    tmp=front;
    front=front->nxtptr;
    return (tmp->data);
    free(tmp);
    }
    }
    void exit(){
    return 0;
    }
