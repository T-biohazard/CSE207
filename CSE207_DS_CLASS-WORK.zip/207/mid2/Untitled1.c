#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Node{
    char ch;
    struct Node *next;
}*head=NULL;

void push(char c);
void val();

int main()
{
    printf("String:");
    char s[50];
    scanf("%s",s);
    printf("index: ");
    int index;
    scanf("%d",&index);
    int start=0,strt[100],stop=0,e[100];
    int length=strlen(s);
    int i;
    for(i=0; i<length; i++){
        if(s[i]=='['){
            strt[start]=i;
            start++;
        }
        else if(s[i]==']'){
            e[stop]=i;
            stop++;
        }
        push(s[i]);

    }
    int count=0;
    for(i=0; i<index; i++){
        if(s[i]=='['){
            count++;
        }
    }
    printf("Output: %d\n",e[index]);

}
void push(char c){
    struct Node *temp,*ptr;
    temp=(struct Node*)malloc(sizeof(struct Node));
    if(c=='['){
        temp->ch=c;
    if(head==NULL){
        head=temp;
        temp->next=NULL;
    }else{
        ptr=head;
        temp->next=ptr;
        head=temp;
    }
    }
}
