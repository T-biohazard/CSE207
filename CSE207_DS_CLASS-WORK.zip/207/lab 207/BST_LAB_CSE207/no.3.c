
#include<stdio.h>

struct Node{
    int data;
    struct Node *left;
    struct Node *right;
};
struct Node *root;
void inorderTraversal(struct Node* root)
{
    if(root==NULL)
        return;
    inorderTraversal(root->left);
    printf("%d ",root->data);
    inorderTraversal(root->right);
}
void insert(int data)
{
   struct Node *tempNode = (struct Node*) malloc(sizeof(struct Node));
   struct Node *current;
   struct Node *parent;

   tempNode->data = data;
   tempNode->left = NULL;
   tempNode->right = NULL;

   if(root == NULL) {
      root = tempNode;
   }
   else {
      current = root;
      parent = NULL;

      while(1) {
         parent = current;

         if(data < parent->data) {
            current = current->left;

            if(current == NULL) {
               parent->left = tempNode;
               return;
            }
         }
         else {
            current = current->right;

            if(current == NULL) {
               parent->right = tempNode;
               return;
            }
         }
      }
   }
}
struct Node *deleteNode(struct Node *root,  int key)

{

  if (root == NULL)
    return root;

  if (key < root->data)
    root->left = deleteNode(root->left, key);
  else if (key > root->data)
    root->right = deleteNode(root->right, key);

  else
    {

    if (root->left == NULL) {
      struct node *temp = root->right;
      free(root);
      return temp;
    }
     else if (root->right == NULL) {
      struct node *temp = root->left;
      free(root);
      return temp;
    }
    struct Node *temp = minValueNode(root->right);
    root->data = temp->data;

    root->right = deleteNode(root->right, temp->data);
  }
  return root;
}

void minValueNode(struct Node *node) {
  struct Node *current = node;
  while (current && current->left != NULL)
    current = current->left;

  return current;
}

int main()
{
    int num,n,key;
    printf("How many node you want: ");
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
    printf("Enter data: ");
    scanf("%d",&num);
    insert(num);
    }

    printf("In order Traversal: \n");
    inorderTraversal(root);
    printf("\nEnter the number you want to delete: ");
    scanf("%d",&key);
    deleteNode(root,key);
    inorderTraversal(root);
    printf("\n");
    preorderTraversal(root);
}
void preorderTraversal(struct Node* root)
{
    if(root==NULL)
        return;
    printf("%d ",root->data);
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}

