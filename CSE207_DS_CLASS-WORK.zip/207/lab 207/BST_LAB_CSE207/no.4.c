
#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *left;
    struct Node *right;
};

struct Node *root;
void inorderTraversal(struct Node* root)
{
    if(root==NULL)
        return;
    inorderTraversal(root->left);
    printf("%d ",root->data);
    inorderTraversal(root->right);
}
int main()
{
    int num,n;
    printf("Num of Node: ");
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
    printf("Enter data: ");
    scanf("%d",&num);
    insert(num);
    }

    printf("In order Traversal: \n");
    inorderTraversal(root);

    CHECK(root);
}

int BST_or_Not(struct Node *root)
{
    if(root==NULL)
        return 1;
    else if(root->left!=NULL && root->left>root->data)
        return 0;
    else if(root->right!=NULL && root->right<root->data)
        return 0;
    else if(!BST_or_Not(root->left)|| !BST_or_Not(root->right))
        return 0;
    else
        return 1;
}
void CHECK(struct Node *root)
{
    if(BST_or_Not(root)!=1)
    {
        printf("\nThe tree is a BST.\n");
    }
    else
        printf("\nThe tree is not BST.\n");
}

void insert(int data)
{
   struct Node *tempNode = (struct Node*) malloc(sizeof(struct Node));
   struct Node *current;
   struct Node *parent;

   tempNode->data = data;
   tempNode->left = NULL;
   tempNode->right = NULL;

   if(root == NULL) {
      root = tempNode;
   }
   else {
      current = root;
      parent = NULL;

      while(1) {
         parent = current;

         if(data < parent->data) {
            current = current->left;

            if(current == NULL) {
               parent->left = tempNode;
               return;
            }
         }
         else {
            current = current->right;

            if(current == NULL) {
               parent->right = tempNode;
               return;
            }
         }
      }
   }
}
