#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *left;
    struct Node *right;
};

int main()
{
    int n,i,num;
    struct Node *root,*p,*q,*m;
    printf("Enter the number of nodes: ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        p=(struct Node*)malloc(sizeof(struct Node));
        printf("Enter data: ");
        scanf("%d",&num);
        p->data=num;
        p->left=NULL;
        p->right=NULL;
        if(i==1)
        {
            root=p;
        }
        else
        {
            q=root;
            while(1)
            {
                if(p->data>q->data)
                {
                    if(q->right==NULL)
                    {
                        q->right=p;
                        break;
                    }
                    else
                    {
                        q=q->right;
                    }
                }
                else
                {
                    if(q->left==NULL)
                    {
                        q->left=p;
                        break;
                    }
                    else
                    {
                        q=q->left;
                    }
                }
            }
        }
    }

    int a;
    printf("\n\nInput number: ");
    scanf("%d",&a);
    m=findKthLargest(root,a);
    printf("\n%d",m->data);
}

struct Node* Findlarge(struct Node *root,int *i,int k)
{
    if (root ==NULL) {
        return;
    }
    struct Node* left = Findlarge(root->right, i, k);
    if (left) {
        return left;
    }
    if (++*i == k) {
        return root;
    }
    return Findlarge(root->left, i, k);
};
void findKthLargest(struct Node* root, int k)
{
    struct Node *tmp;
    tmp=root;
    int i = 0;
    return Findlarge(tmp, &i,k);
}

