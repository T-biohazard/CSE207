 #include<stdio.h>

 void minHeapify(int a[], int n, int i)
 {
 int left = 2*i+1;
 int right = 2*i+2;
 int root = i;
 if(left<n && a[left]<a[root])
      root = left;
 if(right<n && a[right]<a[root])
      root = right;
 if(root!=i)
 {
    int temp = a[i];
    a[i] =a[root];
    a[root] = temp;
      minHeapify(a,n,root);
 }

 }


 void buildMinHeap(int a[], int n) {
 for(int i=n/2;i>=0;i--)
      minHeapify(a,n,i);

 }


 int kthLargest(int a[], int n, int k)
 {
 int minHeap[k];
 int i;
 for(i=0;i<k;i++)
      minHeap[i] = a[i];
 buildMinHeap(minHeap,k);
 for(i=k;i<n;i++)
 {
      if(a[i]>minHeap[0])
      {
           minHeap[0]=a[i];
           minHeapify(minHeap,k,0);
      }
 }
 return minHeap[0];
 }


 int main()
{
         int n,k,m,i;
         int a[100];
         printf("Enter the size of array: ");
         scanf("%d ",&n);
         for(i=0;i<n;i++)
         {
              scanf("%d",&a[i]);
         }

         printf("Enter the number: ");
         scanf("%d",&k);
         while(k!=0)
         {
                m=kthLargest(a,n,k);
                  printf("%d ",m);
            k--;
         }
 }
