#include <stdio.h>

void Max_heapify();
void buildHeap_max();
void heapSort();
void printArray();


  void Max_heapify(int arr[], int n, int i) {

  int tmp;
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
      largest = left;

    if (right < n && arr[right] > arr[largest])
      largest = right;

    if (largest != i)
        {
      tmp=arr[i];
      arr[i]=arr[largest];
      arr[largest]=tmp;
      Max_heapify(arr, n, largest);
       }
  }


void buildHeap_max(int arr[], int n)
{

  for (int i = n / 2 - 1; i >= 0; i--)
      Max_heapify(arr, n, i);
}

void heapSort(int arr[], int n)
{
    int tmp;
    for (int i = n / 2 - 1; i >= 0; i--)
        Max_heapify(arr, n, i);

    for (int i = n- 1; i > 0; i--) {
              tmp=arr[0];
             arr[0]=arr[i];
              arr[i]=tmp;
        Max_heapify(arr, i, 0);
    }
}
  void printArray(int arr[], int n) {
    for (int i = 0; i < n; ++i)
    printf("%d ", arr[i]);
    printf("\n");
  }

  int main() {
    int arr[100];
    int i,n;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    printf("Enter the elements: \n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }

    printf("Array is : ");
    printArray(arr, n);

    buildHeap_max(arr, n);
    heapSort(arr,n);
    printArray(arr,n);
  }
