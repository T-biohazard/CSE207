#include<stdio.h>
#include<stdlib.h>

#define MAX 100

#define initial 1
#define waiting 2
#define visited 3

int n;
int adj[MAX][MAX];
int state[MAX];
void create_graph();
void BF_Traversal();
void BFS(int v);

int queue[MAX];
int front = -1;
int rear = -1;
void Enqueue(int vertex);
int Dqueue();
int isEmpty_queue();

int main()
{
create_graph();
BF_Traversal();
return 0;
}

void BF_Traversal()
{
    int v;
    for(v=0; v<n; v++)
    state[v] = initial;
    printf("Enter Start Vertex for BFS: \n");
    scanf("%d", &v);
    BFS(v);
}

void BFS(int v)
{
    int i;
    Enqueue(v);
    state[v] = waiting;
    while(!isEmpty_queue())
    {
    v = Dqueue( );
    printf("%d ",v);
    state[v] = visited;
        for(i=0; i<n; i++)
        {
            if(adj[v][i] == 1 && state[i] == initial)
            {
            Enqueue(i);
            state[i] = waiting;
            }
        }
    }
    printf("\n");
}

void Enqueue(int vertex)
{
    if(rear==MAX-1)
    {
        printf("Queue overflow.\n");
    }
    else
    {
        if(front==-1)
        {
            front=0;
        }
        rear=(rear+1)%MAX;
        queue[rear]=vertex;
    }
}

int isEmpty_queue()
{
    if(front == -1 || front > rear)
    return 1;
    else
    return 0;
}

int Dqueue()
{

     for(int i=front;i<=rear;i++)
        {
        if(front==-1||front>rear)
        {
        printf("Queue Underflow.\n");
        return;
        }
        else
        {
            int x=queue[front];
            front++;
            return x;
        }
        }
}

void create_graph()
{
        int i,edge,a,b;

        printf("Enter number of vertices : ");
        scanf("%d",&n);
        edge = n*(n-1);

        for(i=0; i<edge; i++)
        {
        printf("Enter edge %d( press -1 and -1 to quit ) : ",i);
        scanf("%d %d",&a,&b);

        if((a == -1) && (b == -1))
        break;

        if(a>=n || b>=n || a<0 || b<0)
        {
        printf("Invalid edge!\n");
        i--;
        }
        else
        {
        adj[a][b] = 1;
        }
        }
}
