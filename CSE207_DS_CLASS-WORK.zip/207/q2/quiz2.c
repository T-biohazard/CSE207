#include <stdio.h>
    #include <stdlib.h>

    int arr[100];
    int rear = -1;
    int front = -1,i;
    void enqueue();
    void dequeue();
    void display();
    void odd();



    int main ()
    {
    int i;
    while (1)
    {

    printf("Press 1 to enqueue\n");
    printf("Press 2 to dequeue\n");
    printf("Press 3 to display\n");
    printf("Press 4 to exit\n");
    printf("Press 5 to print the stack where the order of odd & even will be shown as question:\n");
    printf("enter the number:");
    scanf("%d",& i);

    if (i == 1)
    {
    enqueue();
    }

    if (i == 2)
    {
    dequeue();
    }
    if (i == 3)
    {
    display();
    }
    if (i == 4)
    {
    break;
    }
    if (i == 5)
    {
    odd();
    }
    }


    }



    void odd()
    {

    if (front > rear)
    {
    for(i=front; i<=10; i++)
    {
    printf("%d\n",arr[i]);
    }
    for(i=0; i<=rear; i++)
    {
    printf("%d\n",arr[i]);
    }
    }
    else
    {
    for(i=front; i<=rear; i++)
    {
    if (arr[i]%2==1)
    {


    printf("%d\n",arr[i]); }
    }
    for(i=front; i<=rear; i++)
    {
    if (arr[i]%2==0)
    {


    printf("%d\n",arr[i]); }
    }
    }
    }




    void enqueue ()
    {
    int n;
printf("Enqueue: ");
    scanf("%d",& n);
    if (front = -1)
    {
    front++;
    }
    rear++;

    arr [rear %10] = n;
    }

    void dequeue ()
    {

    front = front+1;
    }

    void display ()
    {


    if (front > rear)
    {
    for(i=front; i<=10; i++)
    {
    printf("%d\n",arr[i]);
    }
    for(i=0; i<=rear; i++)
    {
    printf("%d\n",arr[i]);
    }
    }
    else
    {
    for(i=front; i<=rear; i++)
    {
    printf("%d\n",arr[i]);
    }
    }
    }

