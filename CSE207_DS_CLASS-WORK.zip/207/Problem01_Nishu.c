#include <stdio.h>
#include <stdlib.h>


struct node
{
int data;
struct node *next;
} * head;



void createList(int n);
void displayList();
int  count(struct node *list);
int  swap(struct node *list, int x, int y);


void createList(int n)
{
struct node *newNode, *temp;
int data, i;

head = malloc(sizeof(struct node));


if (head == NULL)
{
printf("Unable to allocate memory.");
exit(0);
}

printf("Enter data of node 1: ");
scanf("%d", &data);

head->data = data;
head->next = NULL;

temp = head;

for (i = 2; i <= n; i++)
{
newNode = malloc(sizeof(struct node));


if (newNode == NULL)
{
printf("Unable to allocate memory. Exiting from app.");
exit(0);
}

printf("Enter data of node %d: ", i);
scanf("%d", &data);

newNode->data = data;
newNode->next = NULL;

temp->next = newNode;
temp = temp->next;
}

}



void displayList()
{
struct node *temp;

if (head == NULL)
{
printf("List is empty.\n");
return;
}

temp = head;
while (temp != NULL)
{
printf("%d, ", temp->data);
temp = temp->next;
}
printf("\n");
}



int count(struct node *list)
{
int nodes = 0;

while (list != NULL)
{
nodes++;
list = list->next;
}

return nodes;
}



int swap(struct node *list, int x, int y)
{
struct node *node1, *node2, *prev1, *prev2, *temp;
int i;


const int maxPos = (x > y) ? x : y;


const int totalNodes = count(list);


if ((x <= 0 || x > totalNodes) || (y <= 0 || y > totalNodes))
{
return -1;
}


if (x == y)
{
return 1;
}



i = 1;
temp  = list;
prev1 = NULL;
prev2 = NULL;


while (temp != NULL && (i <= maxPos))
{
if (i == x - 1)
prev1 = temp;
if (i == x)
node1 = temp;

if (i == y - 1)
prev2 = temp;
if (i == y)
node2 = temp;

temp = temp->next;
i++;
}


if (node1 != NULL && node2 != NULL)
{

if (prev1 != NULL)
prev1->next = node2;


if (prev2 != NULL)
prev2->next = node1;


temp        = node1->next;
node1->next = node2->next;
node2->next = temp;

if (prev1 == NULL)
head = node2;
else if (prev2 == NULL)
head = node1;
}

return 1;
}

int main()
{
int n, x, y;


printf("Enter number of node to create: ");
scanf("%d", &n);

createList(n);

// Display list
printf("\n\nData in list before swapping: \n");
displayList();

printf("\nEnter first node position to swap: ");
scanf("%d", &x);
printf("\nEnter second node position to swap: ");
scanf("%d", &y);

if (swap(head, x, y) == 1)
{
printf("\nData swapped successfully.\n");
printf("Data in list after swapping %d node with %d: \n", x, y);
displayList();
}
else
{
printf("Invalid position.\n");
}

return 0;
}
