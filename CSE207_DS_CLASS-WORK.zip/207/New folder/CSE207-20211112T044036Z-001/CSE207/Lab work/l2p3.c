#include <stdio.h>
#include <stdlib.h>

struct node{
int data;
struct node *next;
};
int main(){
int n,d,c=0;
struct node *head,*p,*q;

printf("Input the number of nodes : ");
scanf("%d",&n);

printf("Input data for node 1 :");
scanf("%d",&d);

q = (struct node*)malloc(sizeof(struct node));
q->data = d;
q->next = NULL;
head = q;
p = head;

for(int i=1;i<n;i++){
printf("Input data for node %d: ",i+1);
scanf("%d",&d);

q = (struct node*)malloc(sizeof(struct node));
q->data = d;
q->next = NULL;
p->next = q;
p = p->next;

}
p=head;
printf("\nData entered in the list are:\n");
while(p!=NULL){
    printf("Data: ");
    printf("%d",p->data);
    printf("\n");
    p = p->next;
    c++;
}
printf("Total number of nodes = ");
printf("%d",c);
return 0;
}

