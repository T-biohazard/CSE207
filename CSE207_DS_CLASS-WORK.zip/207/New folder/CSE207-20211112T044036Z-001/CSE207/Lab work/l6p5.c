    //Insertion Sort
    #include<stdio.h>
    void main(){

       int n, i, a[100], j, temp;

       printf("How many data do you want to input: ");
       scanf("%d",&n);

       printf("Input the data: \n", n);

       for(i=0; i<n; i++)
          scanf("%d",&a[i]);

       for(i=1; i<n; i++){
          temp=a[i];
          j=i-1;

          while((temp<a[j])&&(j>=0)){
             a[j+1]=a[j];
             j=j-1;
          }
          a[j+1]=temp;
       }

       printf("Sorted list in reverse order: \n");
       for(i=n-1; i>=0; i--)
          printf("%d\n",a[i]);
    }
