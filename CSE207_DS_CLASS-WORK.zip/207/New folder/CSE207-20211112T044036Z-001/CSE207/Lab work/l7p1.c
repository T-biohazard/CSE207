#include<stdio.h>

//using namespace std;
struct Node
{
    int value;
    Node* left;
    Node* right;
    Node(int v)
    {
        value=v;
        left=NULL;
        right=NULL;
    }
};
Node* add( Node* root, int v)
{
    Node* curr=root;
    if(root==NULL)
    {
        root=new Node(v);
        return root;
    }


    while(1)
    {
        if(curr->value==v)return root;

        else if(curr->value > v)
        {
            if(curr->left==NULL){
              curr->left=new Node(v);
              return root;
            }
            else curr=curr->left;
        }

        else if(curr->value < v)
        {

            if(curr->right==NULL){
              curr->right=new Node(v);
              return root;
            }
            else curr=curr->right;
        }
    }

}

void inorderTraversal_print(Node* root){
   if(root==NULL) return;
   inorderTraversal_print(root->left);
   cout<<root->value<<" ";
   inorderTraversal_print(root->right);
}



int main(){
    Node* head=NULL;

    head=add(head,5);
    head=add(head,6);
    head=add(head,7);
 head=add(head,4);
  head=add(head,3);
   head=add(head,2);
    head=add(head,8);
    inorderTraversal_print(head);



}
