#include<stdio.h>
    int queue[100], queue2[100], choice;
    void enqueue();
    void dequeue();
    void display();
    void delNegative();
    void copy();
    int rear = -1;
    int front = 0;
    int main(){

    printf("\nOperations:\n");
    printf("1.Enqueue\n2.Dequeue\n3.Display\n4.Delete Negative Integers\n5.Exit");
    while(1){
    printf("\nEnter your choice: ");
    scanf("%d",&choice);
    if(choice==1){
        enqueue();
    }
    else if(choice==2){
        dequeue();
    }
    else if(choice==3){
        display();
    }
    else if(choice==4){
        delNegative();
    }
    else if(choice==5){
        printf("Exit point");
        break;
    }
    else{
        printf("Invalid input");
        break;
    }}
    }

    void enqueue(){
        int add;
        printf("Inset the element in queue : ");
        scanf("%d", &add);
        rear = rear + 1;
        queue[rear] = add;
    }

    void dequeue(){
    printf("Element deleted from queue is : %d\n", queue[front]);
            front = front + 1;

    }

    void display(){
        int i;
    printf("Queue is : \n");
            for (i = front; i <= rear; i++)
                printf("%d ", queue[i]);
            printf("\n");
    }

    void delNegative(){
        int i;
    printf("Queue is : \n");
            for (i = front; i <= rear; i++)
                if(queue[i]>0)
                printf("%d ", queue[i]);
            printf("\n");
    }
