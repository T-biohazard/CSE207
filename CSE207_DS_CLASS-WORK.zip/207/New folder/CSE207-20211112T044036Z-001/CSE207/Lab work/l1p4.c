#include <stdio.h>
#include <stdlib.h>
void swap(int *u,int *v){
    int temp;
    temp = *u;
    u*= *v;
    v*= temp;

}
int main()
{
   int a;
   int b;
   int c;

   printf("Enter numbers: ");
   scanf("%d%d%d",&a,&b,&c);
   swap(&a,&b);
   swap (&b,&c);
    printf("%d%d%d",a,b,c);
}
