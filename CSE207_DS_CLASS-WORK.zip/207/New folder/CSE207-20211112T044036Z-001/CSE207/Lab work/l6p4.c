//Bubble Sort
#include <stdio.h>
void main()
{
  int n, i, a[100], j, temp;

  printf("How many data do you want to input: ");
  scanf("%d", &n);

  printf("Input the data: \n", n);

  for(i=0; i<n; i++)
    scanf("%d", &a[i]);

  for(i=0; i<n-1; i++)
  {
    for(j=0; j<n-i-1; j++)
    {
      if(a[j] > a[j+1])
      {
        temp=a[j];
        a[j]=a[j+1];
        a[j+1]=temp;
      }
    }
  }

  printf("Sorted list: \n");

  for(i=0; i<n; i++)
     printf("%d\n", a[i]);
}
