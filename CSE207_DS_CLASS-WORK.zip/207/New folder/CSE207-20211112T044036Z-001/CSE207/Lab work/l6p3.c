    //Selection Sort
    #include <stdio.h>
    void main()
    {
        int n, i, a[100], num, j, temp;

        printf("How many data do you want to input: ");
        scanf("%d", &n);

        printf("Input the data:\n", n);

        for(i=0; i<n; i++)
            scanf("%d", &a[i]);

        for(i=0; i<(n-1); i++)
        {
            num=i;

            for(j=i+1; j<n; j++)
            {
                if(a[num]<a[j])
                    num=j;
            }
            if(num!=i)
            {
                temp=a[i];
                a[i]=a[num];
                a[num]=temp;
            }
        }
        printf("Sorted list: \n");

        for(i=0; i<n; i++)
        {
            printf("%d\n", a[i]);

        }


    }

