#include <stdio.h>
#include<stdlib.h>

void beg();
void end();
void mid();
void delbeg();
void delend();
void delmid();
void disp();
void find();

struct node
{
    int data;
    struct node *next;
};
struct node *head=NULL, *p, *q;
int main()
{
    int opt,n,w=0,b,x;

    printf("Please insert your option:\n\n1. Insert Node at the beginning\n2. Insert Node at the end\n3. Insert Node at the Middle\n4. Delete Node from beginning\n5. Delete Node from End\n6. Delete Node from Middle\n7. Display the List\n8. Find a Value From the List\n9. Exit your code\n");
    scanf("%d",&opt);

    while(1)
    {
        if(opt==1)
        {
            printf("Enter data: ");
            scanf("%d",&b);
            beg(b);
        }
        else if(opt==2)
        {
            printf("Enter data: ");
            scanf("%d",&b);
            end(b);
        }
        else if(opt==3)
        {
            printf("Enter data: ");
            scanf("%d",&b);
            printf("Enter position: ");
            scanf("%d",&x);
            mid(b,x-1);
        }
        else if(opt==4)
        {
            delbeg();
        }
        else if(opt==5)
        {
            delend();
        }
        else if(opt==6)
        {
            printf("Enter data: ");
            scanf("%d",&b);
            delmid(b);
        }
        else if(opt==7)
        {
            disp();
        }
        else if(opt==8)
        {
            printf("Enter data: ");
            scanf("%d",&b);
            find(b);
        }
        else if(opt==9)
        {
            printf("Successfully exited the code");

            break;
        }
        else
        {
            printf("Your input is wrong. Please choose between 1-9\n");

        }


        printf("Please insert your option:\n\n1. Insert Node at the beginning\n2. Insert Node at the end\n3. Insert Node at the Middle\n4. Delete Node from beginning\n5. Delete Node from End\n6. Delete Node from Middle\n7. Display the List\n8. Find a Value From the List\n9. Exit your code\n");
        scanf("%d",&opt);
    }
}

void beg(int b)
{
    if(head==NULL)
    {
        q = (struct node*)malloc(sizeof(struct node));
        q->data = b;
        q->next = NULL;
        head = q;
    }
    else
    {
        q = (struct node*)malloc(sizeof(struct node));
        q->data = b;
        q->next = head;
        head = q;

    }
}

void end(int b)
{
    if(head==NULL)
    {
        q = (struct node*)malloc(sizeof(struct node));
        q->data = b;
        q->next = NULL;
        head = q;
    }
    else
    {
        q=head;
        while(q->next!=NULL)
        {
            q=q->next;
        }
        p = (struct node*)malloc(sizeof(struct node));
        p->data = b;
        p->next = NULL;
        q->next = p;

    }
}

void mid(int b, int x)
{
    if(head==NULL)
    {
        printf("List is empty\n");
        return;
    }

    else
    {
        q=head;
        int counter=1;
        while(q->next!=NULL)
        {
            counter++;
            q=q->next;
        }

        if(counter<x)
            printf("No such position found\n");
        else if(x==0)
            printf("You are trying to add value in the first position.\nPlease Choose a position from middle\n");

        else if(x+1==counter)
            printf("You are trying to add value in the Last Position.\nPlease Choose a position from middle\n");

        else
        {
            counter=1;
            q=head;
            while(counter!=x)
            {
                counter++;
                q=q->next;
            }

            p = (struct node*)malloc(sizeof(struct node));
            p->data = b;
            p->next = q->next;
            q->next = p;
        }
    }

}

void delbeg()
{

    if(p==NULL)
    {
        printf("List is empty\n");
        return;
    }
    p=head;
    head = head->next;
    free(p);

}

void delend()
{
    p=head;
    if(p==NULL)
    {
        printf("List is empty\n");
        return;
    }
    q = (struct node*)malloc(sizeof(struct node));
    while(p->next->next!=NULL)
    {
        p=p->next;

    }
    free(p->next);
    p->next = NULL;
}


void delmid(int b)
{
    p=head;
    if(p==NULL)
    {
        printf("List is empty\n");
        return;
    }
    if(p->data==b)
    {
        printf("Cannot delete data from head\n");
        return;
    }
    while(p->next!=NULL)
    {
        if(p->next->data==b&&p->next->next==NULL)
        {
            printf("Cannot delete the last data\n");
            return;
        }

        if(p->next->data==b)
        {
            q=p->next;
            p->next=q->next;
            free(q);
            return;
        }
        p=p->next;
    }
    printf("Entered data not found in the list\n");


}

void disp()
{
    p=head;
    if(p==NULL)
    {
        printf("List is empty\n");
    }
    else
    {
        while(p!=NULL)
        {
            printf("Data: ");
            printf("%d\n",p->data);
            p=p->next;
        }

    }
}

void find(int b)
{
    p=head;
    int count=0;
    while(p->next!=NULL)
    {
        count++;
        if(p->data==b)
        {

            printf("%d found in position no %d\n",b,count);
            return;
        }
        p=p->next;
    }
    printf("Sorry no value found");

}
