#include<stdio.h>
struct node
{
    int data;
    struct node* left;
    struct node* right;
};

struct node* newnode(int data)
{
    struct node *t = (struct node*)malloc(sizeof(struct node));
    t->data = data;
    t->left = NULL;
    t->right = NULL;
    return t;
};

struct node*create(struct node* head, int data)
{
    if (head==NULL)
    {
        head = newnode(data);
        return head;
    }
    else if(data<=head->data)
        head->left=create(head->left, data);
    else
        head->right=create(head->right, data);
        return head;

};

void display(struct node* head)
{

    if(head!=NULL)
    {
        display(head->left);
        printf("%d ",head->data);
        display(head->right);

    }
}

void preOrder(struct node* head)
{
    printf("%d ",head->data);
    if(head->left != NULL)
    {
        preOrder(head->left);
    }
    if(head->right != NULL)
    {
        preOrder(head->right);
    }
}
void postOrder(struct node* head)
{

    if(head->left != NULL)
    {
        preOrder(head->left);
    }
    if(head->right != NULL)
    {
        preOrder(head->right);
    }
    printf("%d ",head->data);
}
void inOrder(struct node* head)
{

    if(head->left != NULL)
    {
        preOrder(head->left);
    }
    printf("%d ",head->data);

    if(head->right != NULL)
    {
        preOrder(head->right);
    }

}

int main()
{
    struct node* head=NULL;
    int p,q,i;
    printf("Enter total number of values(don't enter same number twice): ");
    scanf("%d",&p);
    int n[p];

    for(i=0;i<p;i++)
    {
        scanf("%d",&n[i]);

    }
    for(i=0;i<p;i++)
    {
        head=create(head,n[i]);
    }
    printf("BST: ");
    display(head);
    printf("\nPre order: ");
    preOrder(head);
    return 0;
}
