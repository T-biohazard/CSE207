#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Well done\n");
    return 0;
}
