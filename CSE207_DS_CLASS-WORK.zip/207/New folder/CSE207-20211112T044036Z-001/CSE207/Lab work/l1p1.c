#include <stdio.h>
#include <stdlib.h>
int main()
{
    int a;
    int b;
    int s;
    int *u;
    int *v;
    printf("num 1&2: ");
    scanf("%d%d",&a,&b);

    u = &a;
    v = &b;
    s = *u+*v;
    printf("Sum of the numbers: %d", s);
}
//problem 1
