#include<stdio.h>
int top,n;
char stack[100];
void push();
void pop();
int main(){
    top=0;
char stack[100] = "[ABC[23]][89]";
for(int i=0;i<100;i++){
    if(stack[i]=='['){
        push();
    }
    else if(stack[i]==']'){
        pop();
    }
}
printf("Enter index: ");
scanf("%d",&n);
if(n>12)
{
    printf("Value doesn't exist");
}
else
{
    for(int i=0;i<100;i++)
    {
        if(top==0)
        printf("%d",i);
    }
}
}
void push(){

top++;
stack[top]=1;
}

void pop(){
top--;
}
