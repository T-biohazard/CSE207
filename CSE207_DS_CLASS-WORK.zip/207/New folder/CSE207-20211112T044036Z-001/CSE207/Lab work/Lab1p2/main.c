#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    int b;
    int *u;
    int *v;
    int l;
    printf("Enter numbers: ");
    scanf("%d%d",&a,&b);
    u = &a;
    v = &b;
    if(*u>*v){
        l=*u;
    }
    else{
        l=*v;
    }
    printf("Max: %d",l);
}
//problem 2

