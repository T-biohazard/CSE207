#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node* left, *right;

};


struct node* createnode(int key)
{
    struct node* newnode = (struct node*)malloc(sizeof(struct node));
    newnode->info = key;
    newnode->left = NULL;
    newnode->right = NULL;

    return(newnode);
}


int count = 0;
int leafnodes(struct node* newnode)
{

    while (count < 3)
    {
        leafnodes(newnode->left);
        if((newnode->left == NULL) && (newnode->right == NULL))
        {
            count++;
        }
        leafnodes(newnode->right);
    }
    return count;

}

int main()
{

    struct node *newnode = createnode(50);
    newnode->left = createnode(20);
    newnode->right = createnode(70);
    newnode->left->left = createnode(10);
    newnode->left->right = createnode(40);

    printf("Number of leaf nodes in Tree are\t%d\n",leafnodes(newnode));
    count = 0;

    return 0;
}
