#include<stdio.h>
int stack[100], choice, n, top, x, i;
void push();
void pop();
void display();

int main(){
top = -1;
printf("Enter the size of Stack: ");
scanf("%d",&n);
printf("\nOperations:\n");
printf("1. push\n2.pop\n3.display\n4.exit");
do{
printf("\nEnter your choice: ");
scanf("%d",&choice);
if(choice==1){
    push();
}
else if(choice==2){
    pop();
}
else if(choice==3){
    display();
}
else if(choice==4){
    printf("Exit point");
    break;
}
else{
    printf("Invalid input");
    break;
}}
while(choice!=4);
}


void push(){
printf("\nEnter a value to be pushed: ");
scanf("%d",&x);
top++;
stack[top]=x;
}

void pop(){
printf("%d has been popped.",stack[top]);
top--;
}

void display(){
printf("\nStack: \n");
for(i=top;i>=0;i--){
    printf("%d\n",stack[i]);

}
}
