#include <stdio.h>
#include <stdlib.h>

void doublylinkedlist(int n);
void displaydoublylinkedlist();
void randomnode(int num,int pos);

struct node {
    int num;
    struct node * prevptr;
    struct node * nextptr;
}

*stnode, *ennode;
int main()
{
    int n,o,p;
    stnode = NULL;
    ennode = NULL;

    printf("Input the number of nodes: ");
    scanf("%d", &n);

    doublylinkedlist(n);
    printf("node to add : ");
    scanf("%d",&o);
    printf("Value of node: ");
    scanf("%d",&p);
    randomnode(o,p);
    displaydoublylinkedlist();
    return 0;
}

void doublylinkedlist(int n)
{
    int i, num;
    struct node *fnNode;


        stnode = (struct node *)malloc(sizeof(struct node));


            printf(" Input data for node 1 : ");
            scanf("%d", &num);

            stnode->num = num;
            stnode->prevptr = NULL;
            stnode->nextptr = NULL;
            ennode = stnode;
            for(i=2; i<=n; i++)
            {
                fnNode = (struct node *)malloc(sizeof(struct node));

                    printf(" Input data for node %d : ", i);
                    scanf("%d", &num);
                    fnNode->num = num;
                    fnNode->prevptr = ennode;
                    fnNode->nextptr = NULL;

                    ennode->nextptr = fnNode;
                    ennode = fnNode;


            }



}

void displaydoublylinkedlist()
{
    struct node * tmp;
    int n = 1;


        tmp = stnode;
        printf("\n Data entered on the list are :\n");

        while(tmp != NULL)
             {
            printf(" node %d: %d\n", n, tmp->num);
            n++;
            tmp = tmp->nextptr;
            }

}

void randomnode(int num, int pos)
{
    int i=2;
    struct node * newnode, *tmp;


        tmp = stnode;

        while(i<pos)
        {
            tmp = tmp->nextptr;
            i++;
        }

            newnode = (struct node *)malloc(sizeof(struct node));
            newnode->num = num;
            newnode->nextptr = tmp->nextptr;
            newnode->prevptr = tmp;
            if(tmp->nextptr != NULL)
            {
                tmp->nextptr->prevptr = newnode;
            }
            tmp->nextptr = newnode;

}
