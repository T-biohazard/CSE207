#include<stdio.h>

int main()
{
int m;
int n;
int temp;
scanf("%d %d",&m,&n);

while(n != 0){
    temp = n;
    n = m%n;
    m = temp;
}

printf("%d",m);
return 0;
}
