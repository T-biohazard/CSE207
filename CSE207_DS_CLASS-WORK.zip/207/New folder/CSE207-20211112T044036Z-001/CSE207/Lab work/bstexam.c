#include <stdio.h>
#include <stdlib.h>

typedef struct node node;

struct node
{
    char val;
    node *left,*right;
};
node *insert(node *root,char val);
void display(node *root);


int main()
{
    node *root=NULL;


}

node *insert(node *root,char val)
{
    if(root==NULL)
    {
        root=(node*)malloc(sizeof(node));
        root->val=val;
        root->left=root->right=NULL;
    }
    else if(root->val<=val)
        root->right=insert(root->right,val);
    else
        root->left=insert(root->left,val);
    return root;
}

void display(node *root)
{
    if(root==NULL)
        return;
    display(root->left);
    printf("%d ",root->val);
    display(root->right);
}

