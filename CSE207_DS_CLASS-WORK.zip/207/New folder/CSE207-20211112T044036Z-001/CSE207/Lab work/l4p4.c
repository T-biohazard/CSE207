#include<stdio.h>
int top;
char stack[100];
void push();
void pop();
int main(){
    top=0;
char stack[100] = "(((A+B/C))";
for(int i=0;i<100;i++){
    if(stack[i]=='('){
        push();
    }
    else if(stack[i]==')'){
        pop();
    }
}
if(top!=0){
    printf("parentheses not matched");
}
}
void push(){

top++;
stack[top]=1;
}

void pop(){
top--;
}
