    //Binary Search
    #include <stdio.h>
    void main()
    {
      int n, i, a[100], b, fir, las, mid;

      printf("How many data do you want to input: ");
      scanf("%d", &n);

      printf("Input the data: \n", n);

      for(i=0; i<n; i++)
        scanf("%d", &a[i]);

      printf("What element do you want to search: \n");
      scanf("%d", &b);

      fir=0;
      las=n-1;
      mid=(fir+las)/2;

      while(fir<=las) {

        if(a[mid]<b)
          fir=mid+1;

        else if(a[mid]==b) {
          printf("Your element is found in position %d\n", mid+1);
          break;
        }
        else
          las=mid-1;

        mid=(fir+las)/2;
      }
      if(fir>las)
        printf("Data not found in array\n", b);

    }
