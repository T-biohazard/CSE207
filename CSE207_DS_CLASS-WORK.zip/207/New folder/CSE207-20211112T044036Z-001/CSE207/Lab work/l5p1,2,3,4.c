#include<stdio.h>
int queue[100],n,i;
void enqueue();
void display();

int rear = -1;
int front = 0;


int main()
{
    printf("Total number of value: ");
    scanf("%d",&n);
    printf("Inset the element in queue : ");
    for(i=0; i<n; i++)
        enqueue();
    display();
}

void enqueue()
{
    int add;

    scanf("%d", &add);
    rear = rear + 1;
    queue[rear] = add;
}



void display()
{
    int i;
    printf("Queue is : \n");
    for (i = front; i <= rear; i++)
    {
        if(queue[i]%2!=0)
            printf("%d ", queue[i]);
    }


    for (i = front; i <= rear; i++)
    {
        if(queue[i]%2==0)
            printf("%d ", queue[i]);
    }
}


